import React from 'react'
import RestaurantDetails from './RestaurantDetails/RestaurantDetails'
const Day1 = () => {
    return (
        <div>
            <RestaurantDetails />
        </div>
    )
}
export default Day1
