import Day1 from "./components/day-3/Day1";
function App() {
  return (
<>
<Day1/>
</>
  );
}
export default App;
